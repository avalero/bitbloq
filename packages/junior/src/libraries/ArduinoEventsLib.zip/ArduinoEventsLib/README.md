# ArduinoEventsLib
An Arduino library for event-oriented programming (instead of sequential programming)
